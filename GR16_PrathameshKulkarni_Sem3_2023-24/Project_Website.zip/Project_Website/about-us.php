<?//php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from bookland.dexignzone.com/xhtml/shop-registration.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Nov 2023 12:25:28 GMT -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
	<meta name="description" content="Bookland-Book Store Ecommerce Website"/>
	<meta property="og:title" content="Bookland-Book Store Ecommerce Website"/>
	<meta property="og:description" content="Bookland-Book Store Ecommerce Website"/>
	<meta property="og:image" content="../../makaanlelo.com/tf_products_007/bookland/xhtml/social-image.html"/>
	<meta name="format-detection" content="telephone=no">
	
	<!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
	
	<!-- PAGE TITLE HERE -->
	<title>Bookland-Book Store Ecommerce Website</title>
	
	<!-- MOBILE SPECIFIC -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<?php include 'inc/links.php'; ?>
</head>

<body>
	<div class="page-wraper">
		<div id="loading-area" class="preloader-wrapper-1">
			<div class="preloader-inner">
				<div class="preloader-shade"></div>
				<div class="preloader-wrap"></div>
				<div class="preloader-wrap wrap2"></div>
				<div class="preloader-wrap wrap3"></div>
				<div class="preloader-wrap wrap4"></div>
				<div class="preloader-wrap wrap5"></div>
			</div> 
		</div>
		<!-- Header -->
		<?php  include 'inc/header.php'; ?>
		<!-- Header End -->
		
		<div class="page-content bg-white">
		<!--banner-->
		<div class="dz-bnr-inr overlay-secondary-dark dz-bnr-inr-sm" style="background-image:url(images/background/bg3.jpg);">
			<div class="container">
				<div class="dz-bnr-inr-entry">
					<h1>About us</h1>
					<nav aria-label="breadcrumb" class="breadcrumb-row">
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="index.html"> Home</a></li>
							<li class="breadcrumb-item">About us</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
		
		<!--Our Mission Section-->
		<section class="content-inner overlay-white-middle">
			<div class="container">
				<div class="row about-style1 align-items-center">
					<div class="col-lg-6 m-b30">
						<div class="row sp10 about-thumb">
							<div class="col-sm-6 aos-item" data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">
								<div class="split-box">
									<div>
										<img class="m-b30" src="images/about/about1.jpg" alt="">
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="split-box ">
									<div>
										<img class="m-b20 aos-item" src="images/about/about2.jpg" alt="" data-aos="fade-up" data-aos-duration="800" data-aos-delay="500">
									</div>
								</div>
								<div class="exp-bx aos-item"  data-aos="fade-up" data-aos-duration="800" data-aos-delay="500">
									<div class="exp-head">
										<div class="counter-num">
											<h2><span class="counter">50</span><small>+</small></h2>
										</div>
										<h6 class="title">Years of Experience</h6>
									</div>
									<div class="exp-info">
										<ul class="list-check primary">
											<li>Comics & Graphics</li>
											<li>Biography</li>
											<li>Literary Collections</li>
											<li>Children Fiction</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 m-b30 aos-item" data-aos="fade-up" data-aos-duration="800" data-aos-delay="500">
						<div class="about-content px-lg-4">
							<div class="section-head style-1">
								<h2 class="title">Bookland Is Best Choice For Learners</h2>
								<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration which don’t look even slightly believable. It Is A Long Established Fact That A Reader Will Be Distracted</p>
							</div>
							<a href="contact-us.php" class="btn btn-primary btnhover shadow-primary">Contact Us</a>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		
		<!--icon-box3 section-->
		
		
		<!-- Testimonial -->
		
		<!-- Testimonial End -->
		
		<!-- Feature Box -->
		
		<!-- Feature Box End -->
		
		<!-- Client Start-->
		
		<!-- Client End-->
		<!-- Newsletter -->
		
		<!-- Newsletter End -->
		
	</div>
    <br><br><br><br>
		<!-- Footer -->
		<?php  include 'inc/footer.php'; ?>
		<!-- Footer End -->
		
		<button class="scroltop" type="button"><i class="fas fa-arrow-up"></i></button>
	</div>
<?php  include 'inc/script.php'; ?>
</body>

<!-- Mirrored from bookland.dexignzone.com/xhtml/shop-registration.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Nov 2023 12:25:28 GMT -->
</html>